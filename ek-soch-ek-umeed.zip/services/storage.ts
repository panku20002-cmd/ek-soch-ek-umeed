import { Shayari, Story, Photo, UserPreferences } from '../types';
import { INITIAL_SHAYARI, INITIAL_STORIES, INITIAL_PHOTOS } from '../constants';

const KEYS = {
  SHAYARI: 'eseu_shayari',
  STORIES: 'eseu_stories',
  PHOTOS: 'eseu_photos',
  PREFERENCES: 'eseu_preferences',
  ADMIN_SESSION: 'eseu_admin_session'
};

export const StorageService = {
  getShayari: (): Shayari[] => {
    const data = localStorage.getItem(KEYS.SHAYARI);
    if (!data) {
      localStorage.setItem(KEYS.SHAYARI, JSON.stringify(INITIAL_SHAYARI));
      return INITIAL_SHAYARI;
    }
    return JSON.parse(data);
  },

  saveShayari: (shayari: Shayari[]) => {
    localStorage.setItem(KEYS.SHAYARI, JSON.stringify(shayari));
  },

  getStories: (): Story[] => {
    const data = localStorage.getItem(KEYS.STORIES);
    if (!data) {
      localStorage.setItem(KEYS.STORIES, JSON.stringify(INITIAL_STORIES));
      return INITIAL_STORIES;
    }
    return JSON.parse(data);
  },

  saveStories: (stories: Story[]) => {
    localStorage.setItem(KEYS.STORIES, JSON.stringify(stories));
  },

  getPhotos: (): Photo[] => {
    const data = localStorage.getItem(KEYS.PHOTOS);
    if (!data) {
      localStorage.setItem(KEYS.PHOTOS, JSON.stringify(INITIAL_PHOTOS));
      return INITIAL_PHOTOS;
    }
    return JSON.parse(data);
  },

  savePhotos: (photos: Photo[]) => {
    localStorage.setItem(KEYS.PHOTOS, JSON.stringify(photos));
  },

  getPreferences: (): UserPreferences => {
    const data = localStorage.getItem(KEYS.PREFERENCES);
    if (!data) {
      return { theme: 'light', likedItems: [] };
    }
    return JSON.parse(data);
  },

  savePreferences: (prefs: UserPreferences) => {
    localStorage.setItem(KEYS.PREFERENCES, JSON.stringify(prefs));
  },

  isAdminLoggedIn: (): boolean => {
    return localStorage.getItem(KEYS.ADMIN_SESSION) === 'true';
  },

  setAdminSession: (isLoggedIn: boolean) => {
    if (isLoggedIn) {
      localStorage.setItem(KEYS.ADMIN_SESSION, 'true');
    } else {
      localStorage.removeItem(KEYS.ADMIN_SESSION);
    }
  }
};

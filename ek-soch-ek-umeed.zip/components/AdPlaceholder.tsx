import React from 'react';

interface AdPlaceholderProps {
  type: 'banner' | 'sidebar' | 'inline';
  className?: string;
}

const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ type, className = '' }) => {
  let sizeClass = '';
  let label = 'Advertisement';

  switch (type) {
    case 'banner':
      sizeClass = 'h-24 w-full';
      break;
    case 'sidebar':
      sizeClass = 'h-64 w-full';
      break;
    case 'inline':
      sizeClass = 'h-32 w-full';
      break;
  }

  return (
    <div className={`bg-gray-200 dark:bg-gray-800 border-2 border-dashed border-gray-300 dark:border-gray-700 flex items-center justify-center text-gray-400 text-sm uppercase tracking-widest my-6 ${sizeClass} ${className}`}>
      {label}
    </div>
  );
};

export default AdPlaceholder;
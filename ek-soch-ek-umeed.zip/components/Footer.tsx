import React from 'react';
import { Icons } from './Icons';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 mt-auto">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <div className="flex items-center">
              <Icons.Feather className="h-6 w-6 text-primary-600 dark:text-primary-400" />
              <span className="ml-2 text-xl font-bold font-serif text-gray-900 dark:text-white">
                Ek Soch Ek Umeed
              </span>
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-sm">
              Spreading positivity, hope, and inspiration through words and visuals. 
              Join our community of dreamers.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/shayari" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Shayari</Link></li>
              <li><Link to="/stories" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Stories</Link></li>
              <li><Link to="/gallery" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Gallery</Link></li>
              <li><Link to="/admin" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Admin Login</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Privacy Policy</a></li>
              <li><a href="#" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Terms of Service</a></li>
              <li><a href="#" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Disclaimer</a></li>
              <li><a href="#" className="text-base text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400">Contact Us</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-base text-gray-400 text-center md:text-left">
            &copy; {new Date().getFullYear()} Ek Soch Ek Umeed. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
             {/* Social placeholders */}
             <div className="h-6 w-6 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
             <div className="h-6 w-6 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
             <div className="h-6 w-6 bg-gray-300 dark:bg-gray-700 rounded-full"></div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
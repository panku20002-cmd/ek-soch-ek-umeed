import React, { createContext, useContext, useState, useEffect } from 'react';
import { Shayari, Story, Photo, UserPreferences } from '../types';
import { StorageService } from '../services/storage';

interface AppContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  shayari: Shayari[];
  stories: Story[];
  photos: Photo[];
  isAdmin: boolean;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  addShayari: (item: Omit<Shayari, 'id' | 'likes' | 'date'>) => void;
  deleteShayari: (id: string) => void;
  addStory: (item: Omit<Story, 'id' | 'likes' | 'date'>) => void;
  deleteStory: (id: string) => void;
  addPhoto: (item: Omit<Photo, 'id' | 'date'>) => void;
  deletePhoto: (id: string) => void;
  toggleLike: (id: string, type: 'shayari' | 'story') => void;
  isLiked: (id: string) => boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [preferences, setPreferences] = useState<UserPreferences>(StorageService.getPreferences());
  const [shayari, setShayari] = useState<Shayari[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [isAdmin, setIsAdmin] = useState<boolean>(StorageService.isAdminLoggedIn());

  // Load initial data
  useEffect(() => {
    setShayari(StorageService.getShayari());
    setStories(StorageService.getStories());
    setPhotos(StorageService.getPhotos());
  }, []);

  // Theme Management
  useEffect(() => {
    if (preferences.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    StorageService.savePreferences(preferences);
  }, [preferences]);

  const toggleTheme = () => {
    setPreferences(prev => ({
      ...prev,
      theme: prev.theme === 'light' ? 'dark' : 'light'
    }));
  };

  // Admin Actions
  const loginAdmin = (password: string) => {
    // In a real app, verify against a backend
    if (password === 'admin123') {
      setIsAdmin(true);
      StorageService.setAdminSession(true);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdmin(false);
    StorageService.setAdminSession(false);
  };

  // Content Actions
  const addShayari = (item: Omit<Shayari, 'id' | 'likes' | 'date'>) => {
    const newItem: Shayari = {
      ...item,
      id: Date.now().toString(),
      likes: 0,
      date: new Date().toISOString()
    };
    const updated = [newItem, ...shayari];
    setShayari(updated);
    StorageService.saveShayari(updated);
  };

  const deleteShayari = (id: string) => {
    const updated = shayari.filter(s => s.id !== id);
    setShayari(updated);
    StorageService.saveShayari(updated);
  };

  const addStory = (item: Omit<Story, 'id' | 'likes' | 'date'>) => {
    const newItem: Story = {
      ...item,
      id: Date.now().toString(),
      likes: 0,
      date: new Date().toISOString()
    };
    const updated = [newItem, ...stories];
    setStories(updated);
    StorageService.saveStories(updated);
  };

  const deleteStory = (id: string) => {
    const updated = stories.filter(s => s.id !== id);
    setStories(updated);
    StorageService.saveStories(updated);
  };

  const addPhoto = (item: Omit<Photo, 'id' | 'date'>) => {
    const newItem: Photo = {
      ...item,
      id: Date.now().toString(),
      date: new Date().toISOString()
    };
    const updated = [newItem, ...photos];
    setPhotos(updated);
    StorageService.savePhotos(updated);
  };

  const deletePhoto = (id: string) => {
    const updated = photos.filter(p => p.id !== id);
    setPhotos(updated);
    StorageService.savePhotos(updated);
  };

  const toggleLike = (id: string, type: 'shayari' | 'story') => {
    const isAlreadyLiked = preferences.likedItems.includes(id);
    let newLikedItems = [...preferences.likedItems];

    if (isAlreadyLiked) {
      newLikedItems = newLikedItems.filter(item => item !== id);
    } else {
      newLikedItems.push(id);
    }

    setPreferences(prev => ({ ...prev, likedItems: newLikedItems }));

    // Update counts locally
    if (type === 'shayari') {
      const updated = shayari.map(s => s.id === id ? { ...s, likes: s.likes + (isAlreadyLiked ? -1 : 1) } : s);
      setShayari(updated);
      StorageService.saveShayari(updated);
    } else {
      const updated = stories.map(s => s.id === id ? { ...s, likes: s.likes + (isAlreadyLiked ? -1 : 1) } : s);
      setStories(updated);
      StorageService.saveStories(updated);
    }
  };

  const isLiked = (id: string) => preferences.likedItems.includes(id);

  return (
    <AppContext.Provider value={{
      theme: preferences.theme,
      toggleTheme,
      shayari,
      stories,
      photos,
      isAdmin,
      loginAdmin,
      logoutAdmin,
      addShayari,
      deleteShayari,
      addStory,
      deleteStory,
      addPhoto,
      deletePhoto,
      toggleLike,
      isLiked
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/Icons';

const Admin: React.FC = () => {
  const { isAdmin, loginAdmin, addShayari, addStory, addPhoto, shayari, deleteShayari, stories, deleteStory, photos, deletePhoto } = useApp();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'shayari' | 'story' | 'photo'>('shayari');

  // Form States
  const [shayariForm, setShayariForm] = useState({ content: '', category: 'Motivation', author: '' });
  const [storyForm, setStoryForm] = useState({ title: '', content: '', author: '', category: 'Life' });
  const [photoForm, setPhotoForm] = useState({ url: '', caption: '', category: 'Nature' });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginAdmin(password)) {
      setError('');
      setPassword('');
    } else {
      setError('Invalid password. Try "admin123"');
    }
  };

  const handleSubmitShayari = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shayariForm.content) return;
    addShayari(shayariForm);
    setShayariForm({ content: '', category: 'Motivation', author: '' });
    alert('Shayari added successfully!');
  };

  const handleSubmitStory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storyForm.title || !storyForm.content) return;
    addStory(storyForm);
    setStoryForm({ title: '', content: '', author: '', category: 'Life' });
    alert('Story added successfully!');
  };

  const handleSubmitPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoForm.url) return;
    addPhoto(photoForm);
    setPhotoForm({ url: '', caption: '', category: 'Nature' });
    alert('Photo added successfully!');
  };

  if (!isAdmin) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-xl p-8 border border-gray-200 dark:border-gray-700">
          <div className="text-center mb-8">
            <Icons.Lock className="mx-auto h-12 w-12 text-primary-500" />
            <h2 className="mt-4 text-3xl font-extrabold text-gray-900 dark:text-white">Admin Access</h2>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
              Please enter your credentials to manage content.
            </p>
          </div>
          <form className="space-y-6" onSubmit={handleLogin}>
            <div>
              <label htmlFor="password" className="sr-only">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="appearance-none rounded-md relative block w-full px-3 py-3 border border-gray-300 dark:border-gray-600 placeholder-gray-500 text-gray-900 dark:text-white dark:bg-gray-700 focus:outline-none focus:ring-primary-500 focus:border-primary-500 focus:z-10 sm:text-sm"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {error && <p className="text-red-500 text-sm text-center">{error}</p>}
            <button
              type="submit"
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors"
            >
              Sign in
            </button>
          </form>
          <div className="mt-4 text-center">
            <p className="text-xs text-gray-400">Demo Password: admin123</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="md:flex md:items-center md:justify-between mb-8">
        <div className="flex-1 min-w-0">
          <h2 className="text-2xl font-bold leading-7 text-gray-900 dark:text-white sm:text-3xl sm:truncate">
            Admin Dashboard
          </h2>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-gray-700 mb-8">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          {[
            { id: 'shayari', name: 'Shayari', icon: Icons.Feather },
            { id: 'story', name: 'Stories', icon: Icons.BookOpen },
            { id: 'photo', name: 'Photos', icon: Icons.Image }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`${
                activeTab === tab.id
                  ? 'border-primary-500 text-primary-600 dark:text-primary-400'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 hover:border-gray-300'
              } group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors`}
            >
              <tab.icon className={`${
                activeTab === tab.id ? 'text-primary-500' : 'text-gray-400 group-hover:text-gray-500'
              } -ml-0.5 mr-2 h-5 w-5`} />
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Create Form */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-6 border border-gray-200 dark:border-gray-700 sticky top-24">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6">Add New Content</h3>
            
            {activeTab === 'shayari' && (
              <form onSubmit={handleSubmitShayari} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                  <select
                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                    value={shayariForm.category}
                    onChange={(e) => setShayariForm({...shayariForm, category: e.target.value})}
                  >
                    <option>Motivation</option>
                    <option>Love</option>
                    <option>Life</option>
                    <option>Inspiration</option>
                    <option>Sad</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Content</label>
                  <textarea
                    rows={4}
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={shayariForm.content}
                    onChange={(e) => setShayariForm({...shayariForm, content: e.target.value})}
                    placeholder="Write shayari here..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Author (Optional)</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={shayariForm.author}
                    onChange={(e) => setShayariForm({...shayariForm, author: e.target.value})}
                  />
                </div>
                <button type="submit" className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                  <Icons.Plus className="w-4 h-4 mr-2" /> Add Shayari
                </button>
              </form>
            )}

            {activeTab === 'story' && (
              <form onSubmit={handleSubmitStory} className="space-y-4">
                 <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={storyForm.title}
                    onChange={(e) => setStoryForm({...storyForm, title: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={storyForm.category}
                    onChange={(e) => setStoryForm({...storyForm, category: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Content</label>
                  <textarea
                    rows={8}
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={storyForm.content}
                    onChange={(e) => setStoryForm({...storyForm, content: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Author</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={storyForm.author}
                    onChange={(e) => setStoryForm({...storyForm, author: e.target.value})}
                  />
                </div>
                <button type="submit" className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                  <Icons.Plus className="w-4 h-4 mr-2" /> Publish Story
                </button>
              </form>
            )}

            {activeTab === 'photo' && (
              <form onSubmit={handleSubmitPhoto} className="space-y-4">
                 <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image URL</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={photoForm.url}
                    onChange={(e) => setPhotoForm({...photoForm, url: e.target.value})}
                    placeholder="https://..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Caption</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={photoForm.caption}
                    onChange={(e) => setPhotoForm({...photoForm, caption: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Category</label>
                  <input
                    type="text"
                    className="mt-1 shadow-sm block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md focus:ring-primary-500 focus:border-primary-500"
                    value={photoForm.category}
                    onChange={(e) => setPhotoForm({...photoForm, category: e.target.value})}
                  />
                </div>
                <button type="submit" className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                  <Icons.Plus className="w-4 h-4 mr-2" /> Add Photo
                </button>
              </form>
            )}
          </div>
        </div>

        {/* List View */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">Manage Existing Content</h3>
          
          {activeTab === 'shayari' && shayari.map((item) => (
            <div key={item.id} className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 flex justify-between items-start border border-gray-100 dark:border-gray-700">
              <div>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 dark:bg-gray-900 dark:text-primary-300">
                  {item.category}
                </span>
                <p className="mt-2 text-gray-900 dark:text-gray-100 whitespace-pre-line text-sm">{item.content}</p>
              </div>
              <button onClick={() => deleteShayari(item.id)} className="text-red-500 hover:text-red-700 ml-4 p-2">
                <Icons.Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}

          {activeTab === 'story' && stories.map((item) => (
             <div key={item.id} className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 flex justify-between items-start border border-gray-100 dark:border-gray-700">
             <div>
               <h4 className="font-bold text-gray-900 dark:text-white">{item.title}</h4>
               <span className="text-xs text-gray-500">{item.category} | {item.author}</span>
               <p className="mt-2 text-gray-600 dark:text-gray-300 text-sm line-clamp-2">{item.content}</p>
             </div>
             <button onClick={() => deleteStory(item.id)} className="text-red-500 hover:text-red-700 ml-4 p-2">
               <Icons.Trash2 className="w-5 h-5" />
             </button>
           </div>
          ))}

          {activeTab === 'photo' && photos.map((item) => (
             <div key={item.id} className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 flex justify-between items-center border border-gray-100 dark:border-gray-700">
             <div className="flex items-center space-x-4">
               <img src={item.url} alt={item.caption} className="w-16 h-16 object-cover rounded" />
               <div>
                 <h4 className="font-medium text-gray-900 dark:text-white">{item.caption}</h4>
                 <span className="text-xs text-gray-500">{item.category}</span>
               </div>
             </div>
             <button onClick={() => deletePhoto(item.id)} className="text-red-500 hover:text-red-700 p-2">
               <Icons.Trash2 className="w-5 h-5" />
             </button>
           </div>
          ))}

          {((activeTab === 'shayari' && shayari.length === 0) || 
            (activeTab === 'story' && stories.length === 0) || 
            (activeTab === 'photo' && photos.length === 0)) && (
            <div className="text-center py-8 text-gray-500">No content found. Add some!</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;
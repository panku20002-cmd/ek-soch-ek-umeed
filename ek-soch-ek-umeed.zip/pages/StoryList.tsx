import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/Icons';
import AdPlaceholder from '../components/AdPlaceholder';

const StoryList: React.FC = () => {
  const { stories, toggleLike, isLiked } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredStories = stories.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-serif font-bold text-gray-900 dark:text-white sm:text-4xl">
          Inspiring Stories
        </h2>
        <p className="mt-4 text-gray-500 dark:text-gray-400">
          Tales of courage, hope, and resilience.
        </p>
      </div>

       {/* Search */}
       <div className="max-w-xl mx-auto mb-12">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icons.Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-3 border border-gray-300 dark:border-gray-700 rounded-full leading-5 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
            placeholder="Search for inspiration..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-12">
        {filteredStories.map((item, index) => (
          <div key={item.id} className="flex flex-col lg:flex-row bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700">
            <div className="lg:w-1/3 bg-gray-200 dark:bg-gray-700 relative h-64 lg:h-auto">
               {/* Using a deterministic random image based on ID length or index for demo visual variety */}
               <img 
                 src={`https://picsum.photos/600/800?random=${index + 10}`} 
                 alt={item.title}
                 className="absolute inset-0 w-full h-full object-cover"
               />
               <div className="absolute inset-0 bg-black/20"></div>
               <span className="absolute top-4 left-4 bg-white/90 dark:bg-gray-900/90 px-3 py-1 rounded-full text-xs font-bold text-primary-600 uppercase tracking-wide">
                 {item.category}
               </span>
            </div>
            
            <div className="lg:w-2/3 p-8 flex flex-col justify-between">
              <div>
                <h3 className="text-2xl font-serif font-bold text-gray-900 dark:text-white mb-4">
                  {item.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-wrap line-clamp-6">
                  {item.content}
                </p>
                {/* Read more simulated logic could go here */}
              </div>

              <div className="mt-8 pt-6 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <Icons.Feather className="w-4 h-4 mr-1" />
                    {item.author}
                  </div>
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <Icons.BookOpen className="w-4 h-4 mr-1" />
                    5 min read
                  </div>
                </div>
                
                <button 
                  onClick={() => toggleLike(item.id, 'story')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-colors ${
                    isLiked(item.id) 
                      ? 'bg-red-50 text-red-600 dark:bg-red-900/20 dark:text-red-400' 
                      : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300 hover:bg-red-50 hover:text-red-600'
                  }`}
                >
                  <Icons.Heart className={`w-5 h-5 ${isLiked(item.id) ? 'fill-current' : ''}`} />
                  <span className="font-medium">{item.likes}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <AdPlaceholder type="banner" />
    </div>
  );
};

export default StoryList;
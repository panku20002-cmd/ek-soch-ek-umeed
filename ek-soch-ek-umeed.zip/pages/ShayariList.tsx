import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Icons } from '../components/Icons';
import AdPlaceholder from '../components/AdPlaceholder';

const ShayariList: React.FC = () => {
  const { shayari, toggleLike, isLiked } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('All');

  const categories = ['All', ...Array.from(new Set(shayari.map(s => s.category)))];

  const filteredShayari = shayari.filter(item => {
    const matchesSearch = item.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'All' || item.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-serif font-bold text-gray-900 dark:text-white sm:text-4xl">
          Soulful Shayari
        </h2>
        <p className="mt-4 text-gray-500 dark:text-gray-400">
          Words that touch the heart and soothe the soul.
        </p>
      </div>

      {/* Search and Filter */}
      <div className="mb-8 flex flex-col sm:flex-row gap-4 justify-between items-center">
        <div className="relative w-full sm:w-96">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icons.Search className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md leading-5 bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
            placeholder="Search shayari..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 w-full sm:w-auto no-scrollbar">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                filterCategory === cat
                  ? 'bg-primary-600 text-white'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredShayari.map((item) => (
          <div key={item.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6 flex flex-col h-full border border-gray-100 dark:border-gray-700">
            <div className="flex-1">
              <span className="inline-block px-2 py-1 text-xs font-semibold tracking-wide text-primary-600 dark:text-primary-400 uppercase bg-primary-50 dark:bg-gray-900 rounded-full mb-4">
                {item.category}
              </span>
              <p className="poetic text-lg text-gray-800 dark:text-gray-200 whitespace-pre-line leading-relaxed italic mb-4">
                "{item.content}"
              </p>
              {item.author && (
                <p className="text-right text-sm text-gray-500 dark:text-gray-400 font-medium">
                  - {item.author}
                </p>
              )}
            </div>
            
            <div className="mt-6 flex items-center justify-between border-t border-gray-100 dark:border-gray-700 pt-4">
              <button 
                onClick={() => toggleLike(item.id, 'shayari')}
                className={`flex items-center space-x-1 text-sm font-medium transition-colors ${
                  isLiked(item.id) 
                    ? 'text-red-500' 
                    : 'text-gray-500 hover:text-red-500'
                }`}
              >
                <Icons.Heart className={`w-5 h-5 ${isLiked(item.id) ? 'fill-current' : ''}`} />
                <span>{item.likes}</span>
              </button>
              
              <button className="text-gray-400 hover:text-primary-500 transition-colors">
                <Icons.Share2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredShayari.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 dark:text-gray-400">No shayari found matching your criteria.</p>
        </div>
      )}

      <AdPlaceholder type="inline" />
    </div>
  );
};

export default ShayariList;
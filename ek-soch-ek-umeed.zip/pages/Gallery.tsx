import React from 'react';
import { useApp } from '../context/AppContext';
import AdPlaceholder from '../components/AdPlaceholder';

const Gallery: React.FC = () => {
  const { photos } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
       <div className="text-center mb-12">
        <h2 className="text-3xl font-serif font-bold text-gray-900 dark:text-white sm:text-4xl">
          Visual Symphony
        </h2>
        <p className="mt-4 text-gray-500 dark:text-gray-400">
          Moments of beauty captured forever.
        </p>
      </div>

      <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
        {photos.map((photo) => (
          <div key={photo.id} className="break-inside-avoid bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 group">
            <div className="relative overflow-hidden">
              <img 
                src={photo.url} 
                alt={photo.caption} 
                className="w-full h-auto object-cover transform transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <div className="p-4 w-full">
                  <p className="text-white font-medium text-lg">{photo.caption}</p>
                  <span className="text-white/80 text-sm">{photo.category}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-12">
         <AdPlaceholder type="banner" />
      </div>
    </div>
  );
};

export default Gallery;
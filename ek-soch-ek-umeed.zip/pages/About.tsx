import React from 'react';
import AdPlaceholder from '../components/AdPlaceholder';

const About: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white dark:bg-gray-800 shadow-xl rounded-2xl overflow-hidden">
        <div className="h-48 bg-primary-600 w-full relative">
           <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
             <h1 className="text-4xl font-serif font-bold text-white">About Us</h1>
           </div>
        </div>
        
        <div className="p-8 md:p-12 space-y-6">
          <div className="prose dark:prose-invert max-w-none">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Ek Soch Ek Umeed</h2>
            <p className="text-gray-600 dark:text-gray-300">
              Welcome to <strong>Ek Soch Ek Umeed</strong> (One Thought, One Hope). We are a platform dedicated to spreading positivity in a world that often feels chaotic. We believe that a single positive thought has the power to change a life, and a glimmer of hope can illuminate the darkest paths.
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              Our collection of Shayari, Stories, and Photography is carefully curated to uplift your spirits, motivate you to achieve your dreams, and remind you of the beauty that exists in everyday moments.
            </p>

            <h3 className="text-xl font-bold text-gray-900 dark:text-white mt-8">Our Mission</h3>
            <ul className="list-disc pl-5 text-gray-600 dark:text-gray-300 space-y-2">
              <li>To inspire millions through the power of words.</li>
              <li>To provide a digital sanctuary for mental peace and motivation.</li>
              <li>To connect like-minded individuals who believe in the power of hope.</li>
            </ul>
          </div>

          <div className="border-t border-gray-200 dark:border-gray-700 pt-8 mt-8">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Contact Us</h2>
            <form className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
                <input type="text" className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-primary-500 focus:ring-primary-500 py-3 px-4" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email</label>
                <input type="email" className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-primary-500 focus:ring-primary-500 py-3 px-4" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                <textarea rows={4} className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 dark:bg-gray-700 shadow-sm focus:border-primary-500 focus:ring-primary-500 py-3 px-4"></textarea>
              </div>
              <button className="bg-primary-600 text-white py-3 px-6 rounded-md hover:bg-primary-700 transition-colors w-full sm:w-auto">
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <AdPlaceholder type="banner" />
      </div>
    </div>
  );
};

export default About;